#pragma once

class Cosiek2 {
    public:
        void info();
        Cosiek2(int _numerek = 69);
        ~Cosiek2();
        int* numerek;
};
