#pragma once

class punkt {
public:
    int x;
    int y;
    punkt();
    punkt(int x, int y);
    ~punkt();
};

