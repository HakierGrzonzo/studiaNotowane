W celu kompilacji:

$ make

W celu uruchomienia:

$ make run

jak zainstalować make w windowsie: https://stackoverflow.com/questions/32127524/how-to-install-and-use-make-in-windows

Powinno działać w WSL bez problemów.
