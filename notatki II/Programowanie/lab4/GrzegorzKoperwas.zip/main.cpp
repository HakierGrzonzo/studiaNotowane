#include <iostream>
#include "classes.hpp"
using namespace std;

int main()
{
    A a;
    a.apub;
    a.aprot;
    a.apriv;
    B b;
    b.apub;
    b.aprot;
    b.apriv;
    b.bpub;
    b.bprot;
    b.bpriv;
    C c;
    c.apub;
    c.aprot;
    c.apriv;
    c.bpub;
    c.bprot;
    c.bpriv;
    c.cpub;
    c.cprot;
    c.cpriv;
}
